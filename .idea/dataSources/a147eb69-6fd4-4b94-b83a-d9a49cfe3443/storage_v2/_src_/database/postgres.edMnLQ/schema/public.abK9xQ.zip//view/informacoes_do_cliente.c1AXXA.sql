create view informacoes_do_cliente(cliente_id, nome, cpf, conta_id, numero_conta, tipo_conta, saldo) as
SELECT c.id  AS cliente_id,
       c.nome,
       c.cpf,
       ct.id AS conta_id,
       ct.numero_conta,
       ct.tipo_conta,
       ct.saldo
FROM cliente c
         JOIN contas ct ON c.id = ct.cliente_id;

alter table informacoes_do_cliente
    owner to admin;

